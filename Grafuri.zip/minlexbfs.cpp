#include <algorithm>
#include <string.h>
#include <vector>
#include <iostream>
#include <fstream>
#include <queue>
using namespace std;

#define KMAX 100001

vector<int> adj[KMAX];
vector<bool> visited(KMAX,false);
vector<int> result;
int n,m;

//functie care implementeaza exact metoda bfs,
//cu mentiunea ca listele de adiacenta au fost deja sortate
//pentru a se obtine parcurgerea minima lexicografica.
void minlexbfs(){
	queue<int> myqueue;
	myqueue.push(1);
	visited[1] = true;
	while(myqueue.size() > 0){
		int node = myqueue.front();
		result.push_back(node);
		myqueue.pop();
		for(int i = 0; i< adj[node].size(); i++)
			if(!visited[adj[node][i]]){
				visited[adj[node][i]] = true;
				myqueue.push(adj[node][i]);
			}

	}
}


int main(){
	ifstream in("minlexbfs.in");
	ofstream out("minlexbfs.out");
	int x,y;
	//citim datele de intrare
	in>> n>> m;
	for(int i = 0; i < m; i++){
		in >> x >> y;
		adj[x].push_back(y);
		adj[y].push_back(x);
	}

	//sortam listele de adiacenta crescator dupa nodurile pe care le contin.
	for(int i = 1; i <= n; i++)
		sort(adj[i].begin(), adj[i].end());

	//apelam minlexbfs
	minlexbfs();

	//afisam in fisierul de iesire.
	for(int i = 0;i < result.size(); i++)
		out << result[i] << " "; 
}