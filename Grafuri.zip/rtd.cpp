#include <fstream>
#include <vector>
#include <algorithm>
#include <queue>
#include <iostream>
using namespace std;

const int kNmax = 100005;

class Task {
 public:
	void solve(){
		read_input();
		print_output(get_result());
	}

 private:
	int n;
	int m;
	vector<int> adj[kNmax];
	vector<bool> visited;
	vector<int> discovery_time;
	vector<int> low_time;
	vector<int> parent;
	
	struct Edge {
		int x;
		int y;
	};

	void read_input() {
		ifstream fin("disjcnt.in");
		fin >> n >> m;
		for (int i = 1, x, y; i <= m; i++) {
			fin >> x >> y;
			adj[x].push_back(y);
			adj[y].push_back(x);
		}
		fin.close();
	}


	void dfs(int node,int &nr){
		if(!visited[node]){
			nr++;
			visited[node] = true;
			for(int i=0;i<adj[node].size();i++)
				dfs(adj[node][i],nr);
		}
	}


	long long get_result() {
		/*
		TODO: Gasiti muchiile critice ale grafului neorientat stocat cu liste
		de adiacenta in adj.
		*/

		visited.resize(n+1,false);
		discovery_time.resize(n+1);
		low_time.resize(n+1);
		parent.resize(n+1,-1);
		vector<Edge> sol;

		
		for(int i=1;i<=n;i++)
			if(!visited[i])
				bridge(i,sol);

		long long suma=0;

		for(int i=0;i<sol.size();i++){
			adj[sol[i].x].erase(std::remove(adj[sol[i].x].begin(), adj[sol[i].x].end(), sol[i].y), adj[sol[i].x].end());
			adj[sol[i].y].erase(std::remove(adj[sol[i].y].begin(), adj[sol[i].y].end(), sol[i].x), adj[sol[i].y].end());
		}

		for(int i=1;i<=n;i++)
			visited[i] = false;

		for(int i=1;i<=n;i++){
			if(!visited[i]){
				int nr = 0;
				dfs(i,nr);
				cout<<"nr este "<<nr<<endl	;
				suma += 1LL*nr*(nr-1)/2;
			}
		}
		printf("%d",suma);
	return suma;

	}



	bool contains_more(int node,int next){
		int nr=0;
		for(int i=0;i<adj[node].size();i++)
			if(adj[node][i] == next){
				nr++;
				if(nr==3)
					return true;
			}
		for(int i=0;i<adj[next].size();i++)
			if(adj[next][i] == node){
				nr++;
				if(nr==3)
					return true;
			}

		return false;
	}

	void bridge(int node,vector<Edge> &sol){
		
		static int time = 0;
		
		visited[node] = true;
		
		low_time[node] = discovery_time[node] = ++time;
		
		int nr_copii=0;
		
		for(int i=0;i<adj[node].size();i++){
			int next_node = adj[node][i];
			
			if(!visited[next_node]){
				parent[next_node] = node;
				bridge(next_node,sol);
				low_time[node] = min(low_time[node],low_time[next_node]);

				if(low_time[next_node] > discovery_time[node] && !contains_more(node,next_node)){
					struct Edge edge;
					edge.x = node;
					edge.y = next_node;
					sol.push_back(edge);
				}

			}
			else if(next_node != parent[node])
				low_time[node] = min(low_time[node],discovery_time[next_node]);
		}

	}



	void print_output(long long result) {
		ofstream fout("disjcnt.out");
		fout<<result;
	}
};

int main() {
	Task *task = new Task();
	task->solve();
	delete task;
	return 0;
}
