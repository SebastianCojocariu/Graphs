#include <fstream>
#include <vector>
#include <algorithm>
#include <queue>
#include <iostream>
using namespace std;

const int kNmax = 501;
const int infinity = 100000000;

class Task {
 public:
	void solve() {
		read_input();
		FloydWarshall();
	}

	typedef struct Query{
		int source;
		int destination;
	}TQuery;

 private:
	int n;
	int m;
	int q;
	int graf[kNmax][kNmax];
	vector<TQuery> queries;

	void read_input() {
		ifstream fin("revedges.in");
		fin >> n >> m >> q;
		//initial,distantele de la oricare 2 noduri sunt infinite.
		for(int i = 1;i <= n; i++)
			for(int j = 1; j <= n; j++)
				graf[i][j] = infinity;
		//pentru muchiile din graf punem costul 0.
		for (int i = 1, x, y; i <= m; i++) {
			fin >> x >> y;
			graf[x][y] = 0;
		}
		//salvam queries in vectorul queries.
		for(int i = 1,x,y;i <= q; i++){
			fin >> x >> y;
			TQuery q;
			q.source = x;
			q.destination = y;
			queries.push_back(q);
		}
		//adaugam la fiecare muchie din graf,muchia opusa de cost 1
		//mai jos am tratat si cazul in care avem muchia (i,j) si (j,i)
		//caz in care nu mai adaugam nimic. 
		for(int i = 1;i <= n; i++)
			for(int j = i+1; j <= n; j++)
				if(graf[i][j] == 0 && graf[j][i] == infinity)
					graf[j][i] = 1;
				else if(graf[i][j] == infinity && graf[j][i] == 0)
					graf[i][j] = 1;

		fin.close();
	}


	void FloydWarshall(){
		int distanta[n+1][n+1];
		
		for(int i = 1; i <= n; i++){
			for(int j = 1; j <= n; j++){
				if(i == j)
					distanta[i][j] = 0;
				else
					distanta[i][j] = graf[i][j];
			}
		}

		//FloydWharsall.
		for(int k = 1; k <= n; k++){
			for(int i = 1; i <= n; i++){
				for(int j = 1; j <= n; j++){
					if(distanta[i][k] != infinity && distanta[k][j] != infinity && distanta[i][j] > distanta[i][k] + distanta[k][j])
						distanta[i][j] = distanta[i][k] + distanta[k][j];
				}
			}
		}

		ofstream out("revedges.out");
		//pentru fiecare query scriem in fisier rezultatul.
		for(int i = 0; i < queries.size(); i++){
			TQuery q = queries[i];
			out << distanta[q.source][q.destination] << endl;
		}

	}

};




int main() {
	Task *task = new Task();
	task->solve();
	delete task;
	return 0;
}
